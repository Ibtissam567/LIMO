import subprocess
from time import sleep
#src/interface_graphique/interface/
#

# commande1 = "cd ~/control_ws"
# commande2 = " source install/setup.bash && ros2 run teleop_twist_keyboard       teleop_twist_keyboard && i "
# controlWS = subprocess.Popen(['gnome-terminal', '--', 'bash', '-c',commande1], shell=True)
# #sleep(5)
# # print("fbgjkdgjk")
# # subprocess.run(['gnome-terminal', '--', 'bash', '-c',commande1],shell=True)
# # sleep(5)
# # subprocess.run(['gnome-terminal', '--', 'bash', '-c',commande2], check=True)
# commande1 = "cd ~/control_ws  ; source install/setup.bash ; ros2 launch sensors_nodes imu_node "
# commande2 = "cd ~/control_ws && . install/setup.bash && ros2 launch teleop_twist_keyboard teleop_twist_keyboard.py  && read -p 'Appuyez sur Enter pour fermer le terminal'"
#
# subprocess.run(['gnome-terminal', '--', 'bash', '-c', f'{commande1}; bash'], check=True)
# # subprocess.run(['gnome-terminal', '--', 'bash', '-c', f'{commande1}; sleep 15; {commande3}; bash'], check=True)
# # subprocess.run(['gnome-terminal', '--', 'bash', '-c', f'{commande2}; bash'], check=True)

import cv2

cap = cv2.VideoCapture(0)

fourcc = cv2.VideoWriter_fourcc(*'XVID')
out = cv2.VideoWriter('output.avi',fourcc, 25.0, (640,480))

while( cap.isOpened() ):
    ret, frame = cap.read()
    if ret == True:
        frame = cv2.flip(frame,1)
        out.write(frame)
        cv2.imshow('frame' , frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    else:
        break

cap.release()
out.release()
cv2.destroyAllWindows()