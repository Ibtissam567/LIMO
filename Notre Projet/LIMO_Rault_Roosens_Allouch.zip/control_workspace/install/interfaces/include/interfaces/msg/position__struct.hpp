// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from interfaces:msg/Position.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__POSITION__STRUCT_HPP_
#define INTERFACES__MSG__POSITION__STRUCT_HPP_

#include <rosidl_generator_cpp/bounded_vector.hpp>
#include <rosidl_generator_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__interfaces__msg__Position __attribute__((deprecated))
#else
# define DEPRECATED__interfaces__msg__Position __declspec(deprecated)
#endif

namespace interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Position_
{
  using Type = Position_<ContainerAllocator>;

  explicit Position_(rosidl_generator_cpp::MessageInitialization _init = rosidl_generator_cpp::MessageInitialization::ALL)
  {
    if (rosidl_generator_cpp::MessageInitialization::ALL == _init ||
      rosidl_generator_cpp::MessageInitialization::ZERO == _init)
    {
      this->positionx = 0.0f;
      this->positiony = 0.0f;
      this->positionfx = 0.0f;
      this->positionfy = 0.0f;
    }
  }

  explicit Position_(const ContainerAllocator & _alloc, rosidl_generator_cpp::MessageInitialization _init = rosidl_generator_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_generator_cpp::MessageInitialization::ALL == _init ||
      rosidl_generator_cpp::MessageInitialization::ZERO == _init)
    {
      this->positionx = 0.0f;
      this->positiony = 0.0f;
      this->positionfx = 0.0f;
      this->positionfy = 0.0f;
    }
  }

  // field types and members
  using _positionx_type =
    float;
  _positionx_type positionx;
  using _positiony_type =
    float;
  _positiony_type positiony;
  using _positionfx_type =
    float;
  _positionfx_type positionfx;
  using _positionfy_type =
    float;
  _positionfy_type positionfy;

  // setters for named parameter idiom
  Type & set__positionx(
    const float & _arg)
  {
    this->positionx = _arg;
    return *this;
  }
  Type & set__positiony(
    const float & _arg)
  {
    this->positiony = _arg;
    return *this;
  }
  Type & set__positionfx(
    const float & _arg)
  {
    this->positionfx = _arg;
    return *this;
  }
  Type & set__positionfy(
    const float & _arg)
  {
    this->positionfy = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    interfaces::msg::Position_<ContainerAllocator> *;
  using ConstRawPtr =
    const interfaces::msg::Position_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<interfaces::msg::Position_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<interfaces::msg::Position_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      interfaces::msg::Position_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<interfaces::msg::Position_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      interfaces::msg::Position_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<interfaces::msg::Position_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<interfaces::msg::Position_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<interfaces::msg::Position_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__interfaces__msg__Position
    std::shared_ptr<interfaces::msg::Position_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__interfaces__msg__Position
    std::shared_ptr<interfaces::msg::Position_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Position_ & other) const
  {
    if (this->positionx != other.positionx) {
      return false;
    }
    if (this->positiony != other.positiony) {
      return false;
    }
    if (this->positionfx != other.positionfx) {
      return false;
    }
    if (this->positionfy != other.positionfy) {
      return false;
    }
    return true;
  }
  bool operator!=(const Position_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Position_

// alias to use template instance with default allocator
using Position =
  interfaces::msg::Position_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace interfaces

#endif  // INTERFACES__MSG__POSITION__STRUCT_HPP_
