// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__POSITION_HPP_
#define INTERFACES__MSG__POSITION_HPP_

#include "interfaces/msg/position__struct.hpp"
#include "interfaces/msg/position__traits.hpp"

#endif  // INTERFACES__MSG__POSITION_HPP_
