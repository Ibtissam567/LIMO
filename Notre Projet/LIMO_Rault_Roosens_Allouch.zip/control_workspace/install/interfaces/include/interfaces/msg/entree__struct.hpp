// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from interfaces:msg/Entree.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__ENTREE__STRUCT_HPP_
#define INTERFACES__MSG__ENTREE__STRUCT_HPP_

#include <rosidl_generator_cpp/bounded_vector.hpp>
#include <rosidl_generator_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__interfaces__msg__Entree __attribute__((deprecated))
#else
# define DEPRECATED__interfaces__msg__Entree __declspec(deprecated)
#endif

namespace interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Entree_
{
  using Type = Entree_<ContainerAllocator>;

  explicit Entree_(rosidl_generator_cpp::MessageInitialization _init = rosidl_generator_cpp::MessageInitialization::ALL)
  {
    if (rosidl_generator_cpp::MessageInitialization::ALL == _init ||
      rosidl_generator_cpp::MessageInitialization::ZERO == _init)
    {
      this->vitess_l = 0.0f;
      this->omega = 0.0f;
    }
  }

  explicit Entree_(const ContainerAllocator & _alloc, rosidl_generator_cpp::MessageInitialization _init = rosidl_generator_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_generator_cpp::MessageInitialization::ALL == _init ||
      rosidl_generator_cpp::MessageInitialization::ZERO == _init)
    {
      this->vitess_l = 0.0f;
      this->omega = 0.0f;
    }
  }

  // field types and members
  using _vitess_l_type =
    float;
  _vitess_l_type vitess_l;
  using _omega_type =
    float;
  _omega_type omega;

  // setters for named parameter idiom
  Type & set__vitess_l(
    const float & _arg)
  {
    this->vitess_l = _arg;
    return *this;
  }
  Type & set__omega(
    const float & _arg)
  {
    this->omega = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    interfaces::msg::Entree_<ContainerAllocator> *;
  using ConstRawPtr =
    const interfaces::msg::Entree_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<interfaces::msg::Entree_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<interfaces::msg::Entree_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      interfaces::msg::Entree_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<interfaces::msg::Entree_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      interfaces::msg::Entree_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<interfaces::msg::Entree_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<interfaces::msg::Entree_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<interfaces::msg::Entree_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__interfaces__msg__Entree
    std::shared_ptr<interfaces::msg::Entree_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__interfaces__msg__Entree
    std::shared_ptr<interfaces::msg::Entree_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Entree_ & other) const
  {
    if (this->vitess_l != other.vitess_l) {
      return false;
    }
    if (this->omega != other.omega) {
      return false;
    }
    return true;
  }
  bool operator!=(const Entree_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Entree_

// alias to use template instance with default allocator
using Entree =
  interfaces::msg::Entree_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace interfaces

#endif  // INTERFACES__MSG__ENTREE__STRUCT_HPP_
