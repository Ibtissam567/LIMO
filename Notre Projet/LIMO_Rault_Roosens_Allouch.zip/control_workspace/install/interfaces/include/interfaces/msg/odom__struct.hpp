// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from interfaces:msg/Odom.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__ODOM__STRUCT_HPP_
#define INTERFACES__MSG__ODOM__STRUCT_HPP_

#include <rosidl_generator_cpp/bounded_vector.hpp>
#include <rosidl_generator_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__interfaces__msg__Odom __attribute__((deprecated))
#else
# define DEPRECATED__interfaces__msg__Odom __declspec(deprecated)
#endif

namespace interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Odom_
{
  using Type = Odom_<ContainerAllocator>;

  explicit Odom_(rosidl_generator_cpp::MessageInitialization _init = rosidl_generator_cpp::MessageInitialization::ALL)
  {
    if (rosidl_generator_cpp::MessageInitialization::ALL == _init ||
      rosidl_generator_cpp::MessageInitialization::ZERO == _init)
    {
      this->leftwheelodom = 0ll;
      this->rightwheelodom = 0ll;
      this->steeringangle = 0.0f;
    }
  }

  explicit Odom_(const ContainerAllocator & _alloc, rosidl_generator_cpp::MessageInitialization _init = rosidl_generator_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_generator_cpp::MessageInitialization::ALL == _init ||
      rosidl_generator_cpp::MessageInitialization::ZERO == _init)
    {
      this->leftwheelodom = 0ll;
      this->rightwheelodom = 0ll;
      this->steeringangle = 0.0f;
    }
  }

  // field types and members
  using _leftwheelodom_type =
    int64_t;
  _leftwheelodom_type leftwheelodom;
  using _rightwheelodom_type =
    int64_t;
  _rightwheelodom_type rightwheelodom;
  using _steeringangle_type =
    float;
  _steeringangle_type steeringangle;

  // setters for named parameter idiom
  Type & set__leftwheelodom(
    const int64_t & _arg)
  {
    this->leftwheelodom = _arg;
    return *this;
  }
  Type & set__rightwheelodom(
    const int64_t & _arg)
  {
    this->rightwheelodom = _arg;
    return *this;
  }
  Type & set__steeringangle(
    const float & _arg)
  {
    this->steeringangle = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    interfaces::msg::Odom_<ContainerAllocator> *;
  using ConstRawPtr =
    const interfaces::msg::Odom_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<interfaces::msg::Odom_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<interfaces::msg::Odom_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      interfaces::msg::Odom_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<interfaces::msg::Odom_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      interfaces::msg::Odom_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<interfaces::msg::Odom_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<interfaces::msg::Odom_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<interfaces::msg::Odom_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__interfaces__msg__Odom
    std::shared_ptr<interfaces::msg::Odom_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__interfaces__msg__Odom
    std::shared_ptr<interfaces::msg::Odom_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Odom_ & other) const
  {
    if (this->leftwheelodom != other.leftwheelodom) {
      return false;
    }
    if (this->rightwheelodom != other.rightwheelodom) {
      return false;
    }
    if (this->steeringangle != other.steeringangle) {
      return false;
    }
    return true;
  }
  bool operator!=(const Odom_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Odom_

// alias to use template instance with default allocator
using Odom =
  interfaces::msg::Odom_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace interfaces

#endif  // INTERFACES__MSG__ODOM__STRUCT_HPP_
