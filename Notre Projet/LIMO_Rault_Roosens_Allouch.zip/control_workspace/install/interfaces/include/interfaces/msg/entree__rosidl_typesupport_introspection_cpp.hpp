// generated from rosidl_typesupport_introspection_cpp/resource/idl__rosidl_typesupport_introspection_cpp.h.em
// with input from interfaces:msg/Entree.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__ENTREE__ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_HPP_
#define INTERFACES__MSG__ENTREE__ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_HPP_


#include "rosidl_generator_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

// TODO(dirk-thomas) these visibility macros should be message package specific
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, interfaces, msg, Entree)();

#ifdef __cplusplus
}
#endif

#endif  // INTERFACES__MSG__ENTREE__ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_HPP_
