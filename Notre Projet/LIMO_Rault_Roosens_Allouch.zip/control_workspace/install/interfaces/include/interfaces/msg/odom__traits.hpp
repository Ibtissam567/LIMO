// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from interfaces:msg/Odom.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__ODOM__TRAITS_HPP_
#define INTERFACES__MSG__ODOM__TRAITS_HPP_

#include "interfaces/msg/odom__struct.hpp"
#include <rosidl_generator_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<interfaces::msg::Odom>()
{
  return "interfaces::msg::Odom";
}

template<>
struct has_fixed_size<interfaces::msg::Odom>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<interfaces::msg::Odom>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<interfaces::msg::Odom>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // INTERFACES__MSG__ODOM__TRAITS_HPP_
