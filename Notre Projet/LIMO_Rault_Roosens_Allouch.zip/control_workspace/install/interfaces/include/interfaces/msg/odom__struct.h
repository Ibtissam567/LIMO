// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from interfaces:msg/Odom.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__ODOM__STRUCT_H_
#define INTERFACES__MSG__ODOM__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Struct defined in msg/Odom in the package interfaces.
typedef struct interfaces__msg__Odom
{
  int64_t leftwheelodom;
  int64_t rightwheelodom;
  float steeringangle;
} interfaces__msg__Odom;

// Struct for a sequence of interfaces__msg__Odom.
typedef struct interfaces__msg__Odom__Sequence
{
  interfaces__msg__Odom * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} interfaces__msg__Odom__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // INTERFACES__MSG__ODOM__STRUCT_H_
