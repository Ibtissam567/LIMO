// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef INTERFACES__MSG__ODOM_HPP_
#define INTERFACES__MSG__ODOM_HPP_

#include "interfaces/msg/odom__struct.hpp"
#include "interfaces/msg/odom__traits.hpp"

#endif  // INTERFACES__MSG__ODOM_HPP_
