# import rclpy
# from rclpy.node import Node
# from pylimo import limo
# #from tutorial_interfaces.msg import Num
# import time
# limo=limo.LIMO()
# limo.EnableCommand()
# from std_msgs.msg import String
#
#
# class MinimalPublisher(Node):
#
#     def __init__(self):
#         super().__init__('linear_velocity')
#         self.publisher_ = self.create_publisher(String, 'topic', 10)
#         timer_period = 0.5  # seconds
#         self.timer = self.create_timer(timer_period, self.timer_callback)
#         self.i = 0
#
#     def timer_callback(self):
#         msg = String()
#         a=GetIMUAccelData()
#         msg.data = str(a)
#         self.publisher_.publish(msg)
#         self.get_logger().info('Publishing: "%s"' % msg.data)
#         self.i += 1
#
#
# def main(args=None):
#     rclpy.init(args=args)
#
#     minimal_publisher = MinimalPublisher()
#
#     rclpy.spin(minimal_publisher)
#
#     # Destroy the node explicitly
#     # (optional - otherwise it will be done automatically
#     # when the garbage collector destroys the node object)
#     minimal_publisher.destroy_node()
#     rclpy.shutdown()
#
#
# if __name__ == '__main__':
#     main()
